disp('This module has been renamed to TrendRR')
trendrr