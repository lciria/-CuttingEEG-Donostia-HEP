function [eixo1,eixo2,precisaopct,pcts,incl,sds,reta]=poincareRR_le_cfg

load poincareRR_params.mat;