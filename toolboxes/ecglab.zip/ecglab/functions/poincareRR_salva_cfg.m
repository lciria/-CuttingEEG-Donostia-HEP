function poincareRR_salva_cfg(eixo1,eixo2,precisaopct,pcts,incl,sds,reta)

save poincareRR_params.mat eixo1 eixo2 precisaopct pcts incl sds reta;
