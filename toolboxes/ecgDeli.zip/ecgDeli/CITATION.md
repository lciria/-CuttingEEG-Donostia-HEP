## Attribution

If you use this software, please cite it as follows:
*Pilia, N., Nagel, C., Lenis, G., Becker, S., Dössel, O., Loewe, A. (2020). ECGdeli - An Open Source ECG Delineation Toolbox for MATLAB. https://github.com/KIT-IBT/ECGdeli 

```bibtex
@misc{ecgdeli,
author    = {Pilia, N., Nagel, C., Lenis, G., Becker, S., D\"ossel, O., Loewe, A.},
title     = {ECGdeli - An Open Source ECG Delineation Toolbox for MATLAB},
year      = {2020},
url       = {https://github.com/KIT-IBT/ECGdeli},
doi       = {https://doi.org/10.5281/zenodo.3944621},
}
```

Please check this information regularly, the citation will be updated soon with a publication.
